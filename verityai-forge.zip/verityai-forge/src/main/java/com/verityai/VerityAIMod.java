package com.verityai;

import com.verityai.client.KeyBindings;
import com.verityai.client.render.VerityRenderer;
import com.verityai.config.VerityConfig;
import com.verityai.entity.ModEntities;
import com.verityai.item.ModCreativeTabs;
import com.verityai.item.ModItems;
import com.verityai.network.NetworkHandler;
import net.minecraftforge.common.MinecraftForge;
import net.minecraftforge.event.entity.EntityAttributeCreationEvent;
import net.minecraftforge.eventbus.api.IEventBus;
import net.minecraftforge.fml.ModLoadingContext;
import net.minecraftforge.fml.common.Mod;
import net.minecraftforge.fml.config.ModConfig;
import net.minecraftforge.fml.event.lifecycle.FMLClientSetupEvent;
import net.minecraftforge.fml.javafmlmod.FMLJavaModLoadingContext;
import net.minecraftforge.client.event.EntityRenderersEvent;
import net.minecraftforge.client.event.RegisterKeyMappingsEvent;
import org.slf4j.Logger;
import com.mojang.logging.LogUtils;

@Mod(VerityAIMod.MOD_ID)
public class VerityAIMod {
    public static final String MOD_ID = "verityai";
    public static final Logger LOGGER = LogUtils.getLogger();

    public VerityAIMod() {
        IEventBus modEventBus = FMLJavaModLoadingContext.get().getModEventBus();

        ModEntities.ENTITY_TYPES.register(modEventBus);
        ModItems.ITEMS.register(modEventBus);
        ModCreativeTabs.CREATIVE_TABS.register(modEventBus);
        NetworkHandler.register();

        modEventBus.addListener(this::commonSetup);
        modEventBus.addListener(this::onClientSetup);
        modEventBus.addListener(this::registerAttributes);
        modEventBus.addListener(this::registerRenderers);
        modEventBus.addListener(this::registerKeyMappings);

        ModLoadingContext.get().registerConfig(ModConfig.Type.CLIENT, VerityConfig.CLIENT_SPEC);

        MinecraftForge.EVENT_BUS.register(this);
    }

    private void commonSetup(final net.minecraftforge.fml.event.lifecycle.FMLCommonSetupEvent event) {
        LOGGER.info("Verity AI mod carregado. Aperte V perto da Verity para conversar.");
    }

    private void onClientSetup(final FMLClientSetupEvent event) {
        // client-only init hook, reserved for future use
    }

    private void registerAttributes(final EntityAttributeCreationEvent event) {
        event.put(ModEntities.VERITY.get(), com.verityai.entity.VerityEntity.createAttributes().build());
    }

    private void registerRenderers(final EntityRenderersEvent.RegisterRenderers event) {
        event.registerEntityRenderer(ModEntities.VERITY.get(), VerityRenderer::new);
    }

    private void registerKeyMappings(final RegisterKeyMappingsEvent event) {
        event.register(KeyBindings.TALK_KEY);
    }
}
