package com.verityai.network;

import com.verityai.entity.VerityEntity;
import net.minecraft.network.FriendlyByteBuf;
import net.minecraft.resources.ResourceLocation;
import net.minecraft.server.level.ServerPlayer;
import net.minecraft.world.entity.item.ItemEntity;
import net.minecraft.world.item.Item;
import net.minecraft.world.item.ItemStack;
import net.minecraft.world.item.Items;
import net.minecraft.world.level.Level;
import net.minecraft.world.phys.Vec3;
import net.minecraftforge.network.NetworkEvent;
import net.minecraftforge.registries.ForgeRegistries;

import java.util.List;
import java.util.function.Supplier;

/**
 * Pacote cliente -> servidor: "a Verity quer dar/dropar este item pro
 * jogador que enviou". O servidor valida o item (tem que existir de
 * verdade no jogo) e a quantidade antes de soltar, pra evitar abuso.
 */
public class GiveItemPacket {
    private static final int MAX_COUNT = 64;

    private final String itemId;
    private final int count;

    public GiveItemPacket(String itemId, int count) {
        this.itemId = itemId;
        this.count = count;
    }

    public static void encode(GiveItemPacket msg, FriendlyByteBuf buf) {
        buf.writeUtf(msg.itemId, 256);
        buf.writeVarInt(msg.count);
    }

    public static GiveItemPacket decode(FriendlyByteBuf buf) {
        return new GiveItemPacket(buf.readUtf(256), buf.readVarInt());
    }

    public static void handle(GiveItemPacket msg, Supplier<NetworkEvent.Context> ctxSupplier) {
        NetworkEvent.Context ctx = ctxSupplier.get();
        ctx.enqueueWork(() -> {
            ServerPlayer player = ctx.getSender();
            if (player == null) return;

            ResourceLocation id = ResourceLocation.tryParse(msg.itemId);
            if (id == null) return;

            Item item = ForgeRegistries.ITEMS.getValue(id);
            if (item == null || item == Items.AIR) return;

            int safeCount = Math.max(1, Math.min(msg.count, MAX_COUNT));
            ItemStack stack = new ItemStack(item, safeCount);

            Level level = player.level();
            Vec3 playerPos = player.position();

            // procura a Verity mais próxima (até 32 blocos) pra soltar o item dela;
            // se não achar nenhuma por perto, solta na frente do próprio jogador
            List<VerityEntity> nearby = level.getEntitiesOfClass(VerityEntity.class,
                    player.getBoundingBox().inflate(32.0));

            Vec3 spawnPos = nearby.isEmpty()
                    ? playerPos.add(0, 1.2, 0)
                    : nearby.get(0).position().add(0, 0.4, 0);

            ItemEntity itemEntity = new ItemEntity(level, spawnPos.x, spawnPos.y, spawnPos.z, stack);
            Vec3 towardsPlayer = playerPos.subtract(spawnPos);
            if (towardsPlayer.lengthSqr() > 0.0001) {
                towardsPlayer = towardsPlayer.normalize().scale(0.12);
            } else {
                towardsPlayer = Vec3.ZERO;
            }
            itemEntity.setDeltaMovement(towardsPlayer.x, 0.25, towardsPlayer.z);
            itemEntity.setPickUpDelay(10);

            level.addFreshEntity(itemEntity);
        });
        ctx.setPacketHandled(true);
    }
}
