package com.verityai.client;

import com.verityai.VerityAIMod;
import com.verityai.entity.BoxEntity;
import net.minecraft.resources.ResourceLocation;
import software.bernie.geckolib.model.GeoModel;

public class BoxModel extends GeoModel<BoxEntity> {

    @Override
    public ResourceLocation getModelResource(BoxEntity entity) {
        return new ResourceLocation(VerityAIMod.MOD_ID, "geo/entity/box.geo.json");
    }

    @Override
    public ResourceLocation getTextureResource(BoxEntity entity) {
        return new ResourceLocation(VerityAIMod.MOD_ID, "textures/entity/box.png");
    }

    @Override
    public ResourceLocation getAnimationResource(BoxEntity entity) {
        return new ResourceLocation(VerityAIMod.MOD_ID, "animations/entity/box.animation.json");
    }
}
