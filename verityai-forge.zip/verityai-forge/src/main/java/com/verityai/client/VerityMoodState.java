package com.verityai.client;

/**
 * Controla qual textura de expressão a Verity deve mostrar, sem precisar
 * de rede - é um estado puramente visual do lado do cliente.
 *
 * Duas coisas independentes:
 * - "neutro": fica true depois de 2 minutos sem conversar com ela (chat,
 *   voz, painel ou botão do inventário - qualquer forma conta).
 * - "falando": fica true por alguns segundos toda vez que uma resposta
 *   dela aparece no chat (a duração é estimada pelo tamanho do texto).
 *
 * getTexture() combina os dois pra escolher entre as 4 texturas:
 * feliz / feliz-falando / neutra / neutra-falando.
 */
public class VerityMoodState {

    private static final long NEUTRAL_AFTER_MS = 2 * 60 * 1000L; // 2 minutos

    private static long lastTalkMillis = System.currentTimeMillis();
    private static long talkingUntilMillis = 0L;

    private VerityMoodState() {}

    /** Chame isso toda vez que o texto de uma resposta da Verity aparecer no chat. */
    public static void onVerityResponded(String responseText) {
        long now = System.currentTimeMillis();
        lastTalkMillis = now;

        int length = responseText == null ? 0 : responseText.length();
        long estimatedDurationMs = Math.min(8000L, Math.max(1200L, length * 50L));
        talkingUntilMillis = now + estimatedDurationMs;
    }

    public static boolean isTalking() {
        return System.currentTimeMillis() < talkingUntilMillis;
    }

    public static boolean isNeutral() {
        return System.currentTimeMillis() - lastTalkMillis >= NEUTRAL_AFTER_MS;
    }
}
