package com.verityai.item;

import com.verityai.VerityAIMod;
import com.verityai.entity.ModEntities;
import net.minecraft.world.item.Item;
import net.minecraftforge.common.ForgeSpawnEggItem;
import net.minecraftforge.registries.DeferredRegister;
import net.minecraftforge.registries.ForgeRegistries;
import net.minecraftforge.registries.RegistryObject;

public class ModItems {
    public static final DeferredRegister<Item> ITEMS =
            DeferredRegister.create(ForgeRegistries.ITEMS, VerityAIMod.MOD_ID);

    /** Ovo de spawn da Verity: amarelo (cor dela) com detalhes escuros, igual os ovos vanilla. */
    public static final RegistryObject<Item> VERITY_SPAWN_EGG = ITEMS.register("verity_spawn_egg",
            () -> new ForgeSpawnEggItem(ModEntities.VERITY, 0xFFD21E, 0x2B2B2B, new Item.Properties()));
}
