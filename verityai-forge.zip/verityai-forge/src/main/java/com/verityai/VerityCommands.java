package com.verityai;

import com.mojang.brigadier.CommandDispatcher;
import com.mojang.brigadier.arguments.StringArgumentType;
import com.verityai.config.VerityConfig;
import net.minecraft.commands.CommandSourceStack;
import net.minecraft.commands.Commands;
import net.minecraft.network.chat.Component;
import net.minecraftforge.event.RegisterCommandsEvent;
import net.minecraftforge.eventbus.api.SubscribeEvent;
import net.minecraftforge.fml.common.Mod;

/**
 * /verityai key <SUA_KEY>  -> salva a API key da Groq (funciona em mundo
 * singleplayer; a key fica só no seu computador/celular, salva em
 * config/verityai-client.toml).
 */
@Mod.EventBusSubscriber(modid = VerityAIMod.MOD_ID)
public class VerityCommands {

    @SubscribeEvent
    public static void onRegisterCommands(RegisterCommandsEvent event) {
        register(event.getDispatcher());
    }

    private static void register(CommandDispatcher<CommandSourceStack> dispatcher) {
        dispatcher.register(Commands.literal("verityai")
                .then(Commands.literal("key")
                        .then(Commands.argument("value", StringArgumentType.greedyString())
                                .executes(ctx -> {
                                    String key = StringArgumentType.getString(ctx, "value");
                                    VerityConfig.setApiKey(key);
                                    ctx.getSource().sendSuccess(() ->
                                            Component.translatable("commands.verityai.key.success"), false);
                                    return 1;
                                }))));
    }
}
