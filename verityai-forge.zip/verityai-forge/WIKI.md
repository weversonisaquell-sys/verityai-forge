# Verity AI — Wiki

Mod para **Minecraft Forge 1.20.1** que adiciona a **Verity**: uma
companheira com inteligência artificial de verdade (via API da Groq),
inspirada na entidade do jogo de terror *Verity*. Converse com ela por
texto, voz ou pelo inventário, peça itens, cuide dela pra ela não ficar
triste, e use a lanterna pra sobreviver às noites escuras.

---

## 📦 Índice

- [Como instalar](#-como-instalar)
- [Como conhecer a Verity](#-como-conhecer-a-verity)
- [Como conversar com ela](#-como-conversar-com-ela)
- [Pedindo itens](#-pedindo-itens)
- [Capturando e soltando](#-capturando-e-soltando)
- [Lanterna e escuridão noturna](#-lanterna-e-escuridão-noturna)
- [Humor e "fome de conversa"](#-humor-e-fome-de-conversa)
- [Comandos](#-comandos)
- [Requisitos](#-requisitos)
- [Perguntas frequentes](#-perguntas-frequentes)

---

## 🔧 Como instalar

1. Baixe o `.jar` do mod (veja a seção [Releases](../../releases) ou
   compile você mesmo a partir do código-fonte).
2. Baixe também o **GeckoLib** (obrigatório, não vem embutido):
   [modrinth.com/mod/geckolib](https://modrinth.com/mod/geckolib/version/rF4Es4hd)
3. Coloque os dois arquivos `.jar` na pasta `mods/` do seu perfil
   **Forge 1.20.1**.
4. Abra o jogo com esse perfil.

## 🔑 Configurando a IA

O mod usa a API da **Groq** (gratuita, sem cartão de crédito) pra dar
inteligência à Verity.

1. Crie sua chave grátis em
   [console.groq.com/keys](https://console.groq.com/keys)
2. Dentro de um mundo, no chat do Minecraft, digite:
   ```
   /verityai key SUA_CHAVE_AQUI
   ```
3. Pronto — a chave fica salva só no seu jogo
   (`config/verityai-client.toml`). **Nunca compartilhe essa chave com
   ninguém.**

## 👋 Como conhecer a Verity

Existem duas formas de trazer a Verity pro seu mundo:

- **Pelo inventário Criativo:** abra a aba própria do mod (ícone do ovo)
  e use o **Ovo de Spawn da Verity**, igual a qualquer ovo de spawn
  vanilla.
- **Por comando** (precisa de cheats ativados):
  ```
  /summon verityai:verity
  ```

Ela aparece como uma **bolinha amarela**, rola pelo chão (sem voar) e
fica te seguindo por perto, tipo um bichinho de estimação.

## 💬 Como conversar com ela

Três jeitos diferentes, todos válidos:

| Jeito | Como fazer |
|---|---|
| **Tecla V** | Segure V, fale, solte — grava sua voz e transcreve automaticamente (experimental: se o microfone não funcionar no seu aparelho, abre o painel de texto sozinho) |
| **Chat digitado** | Digite `Verity sua mensagem` (ou `Verity: sua mensagem`) no chat normal do Minecraft |
| **Inventário** | Abra o inventário normal — tem um botão **"💬 Verity"** no canto que abre o chat direto |

As respostas dela aparecem escritas no chat **e** são faladas em voz alta
(voz feminina, gerada pela mesma API). Como a síntese de voz só existe em
inglês/árabe, o português sai com um sotaque estrangeiro — é uma
limitação da tecnologia, não um bug.

A Verity só conversa sobre **assuntos de Minecraft** — se você perguntar
sobre outra coisa, ela recusa educadamente e puxa o papo de volta pro
jogo.

## 🎁 Pedindo itens

Você pode pedir itens de verdade na conversa:

```
Você: Verity me dá um diamante
[Verity] Ah, um pedaço de estrela cristalizada... aqui está.
```

Ela solta o item de verdade no chão, perto dela. Funciona melhor com
itens comuns do Minecraft (diamante, maçã, pão, tocha, lingote de ferro,
etc). Como quem decide é a IA, pedidos muito específicos ou incomuns
podem não funcionar.

## 🫙 Capturando e soltando

Clique nela (botão direito) pra guardá-la num item no seu inventário.
Usar esse item de novo (clique com o item na mão) solta ela de volta no
mundo, na sua frente.

## 🔦 Lanterna e escuridão noturna

À noite, a tela escurece bastante — igual ao jogo original que inspirou
o mod. Pra enxergar:

1. Pegue a **Lanterna da Verity** (tem modelo 3D próprio, aparece na mão)
2. Clique direito pra ligar/desligar
3. Com ela ligada, você enxerga no escuro e a escuridão pesada não te
   afeta

## 😊 Humor e "fome de conversa"

A Verity tem uma barra de alegria (canto superior direito da tela) e uma
expressão facial que mudam **juntas**, com base na vida real dela:

- **Acima de 60% de vida:** rosto feliz, barra cheia
- **Abaixo de 60%:** rosto neutro, barra baixa
- **Enquanto ela fala:** a expressão ganha uma variante "falando"

Se você ficar **1 minuto inteiro sem conversar com ela** (por qualquer um
dos três jeitos), ela perde vida aos poucos — isso incentiva você a
manter contato com ela regularmente. Não se preocupe: ela nunca morre só
por ficar sem conversa, a vida para num mínimo.

## ⌨️ Comandos

| Comando | O que faz |
|---|---|
| `/verityai key <SUA_CHAVE>` | Configura a API key da Groq |
| `/summon verityai:verity` | Invoca uma Verity (precisa de cheats) |

## ✅ Requisitos

- Minecraft Forge **1.20.1**
- **GeckoLib** 4.4.7+ instalado como mod separado
- Uma API key grátis da Groq
- Conexão com a internet (pra falar com a IA)

## ❓ Perguntas frequentes

**A Verity pode morrer de vez?**
Não por negligência — a vida dela só cai até um mínimo por ficar sem
conversar. Ela pode morrer normalmente se atacada, como qualquer mob.

**Preciso pagar alguma coisa?**
Não. A API da Groq usada pelo mod tem um plano gratuito sem necessidade
de cartão de crédito.

**O microfone não funciona, e agora?**
Depende do seu aparelho/launcher conseguir acessar o microfone via Java
— nem sempre funciona no PojavLauncher. O mod detecta isso sozinho e usa
o painel de texto no lugar, sem travar nada.

**Por que a voz dela tem sotaque?**
A API de texto-pra-voz usada só tem vozes nativas em inglês e árabe, não
existe voz nativa em português ainda — é uma limitação da tecnologia
disponível hoje.
