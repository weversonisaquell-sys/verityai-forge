package com.verityai.ai;

import com.google.gson.JsonObject;
import com.verityai.VerityAIMod;
import com.verityai.config.VerityConfig;

import javax.sound.sampled.AudioInputStream;
import javax.sound.sampled.AudioSystem;
import javax.sound.sampled.Clip;
import javax.sound.sampled.LineEvent;
import java.io.ByteArrayInputStream;
import java.net.URI;
import java.net.http.HttpClient;
import java.net.http.HttpRequest;
import java.net.http.HttpResponse;
import java.nio.charset.StandardCharsets;
import java.time.Duration;
import java.util.concurrent.CompletableFuture;

/**
 * Faz a Verity falar em voz alta (voz feminina) usando a API de
 * texto-pra-voz da Groq (modelo Orpheus). Se o áudio não tocar neste
 * aparelho (alguns ambientes Android/PojavLauncher não suportam saída de
 * áudio via Java Sound), falha silenciosamente - o texto no chat continua
 * funcionando normalmente de qualquer forma.
 */
public class VerityVoiceService {
    public static final VerityVoiceService INSTANCE = new VerityVoiceService();

    private static final String ENDPOINT = "https://api.groq.com/openai/v1/audio/speech";
    private static final String MODEL = "canopylabs/orpheus-v1-english";
    private static final String VOICE = "hannah"; // voz feminina (modelo em inglês - só existe inglês/árabe na Groq)
    private static final int MAX_CHARS = 190; // limite da Orpheus e 200 caracteres

    private final HttpClient client = HttpClient.newBuilder()
            .connectTimeout(Duration.ofSeconds(15))
            .build();

    private volatile boolean voiceEnabled = true;

    public void setVoiceEnabled(boolean enabled) {
        this.voiceEnabled = enabled;
    }

    public boolean isVoiceEnabled() {
        return voiceEnabled;
    }

    public void speakAsync(String text) {
        if (!voiceEnabled || text == null || text.isBlank()) return;

        String apiKey = VerityConfig.getApiKey();
        if (apiKey == null || apiKey.isBlank()) return;

        String cleanText = truncate(text.replaceAll("§.", "").trim());
        if (cleanText.isEmpty()) return;

        JsonObject body = new JsonObject();
        body.addProperty("model", MODEL);
        body.addProperty("input", cleanText);
        body.addProperty("voice", VOICE);
        body.addProperty("response_format", "wav");

        HttpRequest request = HttpRequest.newBuilder()
                .uri(URI.create(ENDPOINT))
                .timeout(Duration.ofSeconds(30))
                .header("Content-Type", "application/json")
                .header("Authorization", "Bearer " + apiKey)
                .POST(HttpRequest.BodyPublishers.ofString(body.toString(), StandardCharsets.UTF_8))
                .build();

        CompletableFuture.supplyAsync(() -> {
            try {
                HttpResponse<byte[]> response = client.send(request, HttpResponse.BodyHandlers.ofByteArray());
                if (response.statusCode() / 100 != 2) {
                    throw new RuntimeException("HTTP " + response.statusCode());
                }
                return response.body();
            } catch (Exception e) {
                throw new RuntimeException(e);
            }
        }).whenComplete((audioBytes, throwable) -> {
            if (throwable != null) {
                VerityAIMod.LOGGER.warn("Falha ao gerar a voz da Verity (TTS)", throwable);
                return;
            }
            playAudio(audioBytes);
        });
    }

    private void playAudio(byte[] wavBytes) {
        try {
            AudioInputStream stream = AudioSystem.getAudioInputStream(new ByteArrayInputStream(wavBytes));
            Clip clip = AudioSystem.getClip();
            clip.open(stream);
            clip.addLineListener(event -> {
                if (event.getType() == LineEvent.Type.STOP) {
                    clip.close();
                }
            });
            clip.start();
        } catch (Exception e) {
            // Ambiente sem suporte a playback de áudio via Java Sound - ignora.
            VerityAIMod.LOGGER.warn("Não foi possível tocar a voz da Verity neste aparelho", e);
        }
    }

    private String truncate(String text) {
        if (text.length() <= MAX_CHARS) return text;
        int cut = text.lastIndexOf(' ', MAX_CHARS);
        if (cut < 0) cut = MAX_CHARS;
        return text.substring(0, cut).trim();
    }
}
