package com.verityai.client.item;

import com.mojang.blaze3d.vertex.PoseStack;
import com.mojang.blaze3d.vertex.VertexConsumer;
import com.verityai.client.render.SphereRenderUtil;
import com.verityai.client.render.VerityRenderer;
import net.minecraft.client.Minecraft;
import net.minecraft.client.renderer.MultiBufferSource;
import net.minecraft.client.renderer.RenderType;
import net.minecraft.client.renderer.blockentity.BlockEntityWithoutLevelRenderer;
import net.minecraft.world.item.ItemDisplayContext;
import net.minecraft.world.item.ItemStack;

/**
 * Faz o ovo de spawn / orbe da Verity aparecerem como uma esfera 3D de
 * verdade (a mesma da entidade) no inventário, na mão e no chão - em vez
 * do ícone chato padrão. Reaproveita o mesmo desenho da entidade
 * (SphereRenderUtil) pra ficar visualmente igual.
 */
public class VeritySphereItemRenderer extends BlockEntityWithoutLevelRenderer {

    public VeritySphereItemRenderer() {
        super(Minecraft.getInstance().getBlockEntityRenderDispatcher(), Minecraft.getInstance().getEntityModels());
    }

    @Override
    public void renderByItem(ItemStack stack, ItemDisplayContext displayContext, PoseStack poseStack,
                              MultiBufferSource buffer, int packedLight, int packedOverlay) {
        poseStack.pushPose();
        poseStack.translate(0.5, 0.5, 0.5);

        float scale = switch (displayContext) {
            case GUI -> 1.0F;
            case GROUND -> 0.8F;
            case FIXED -> 0.9F;
            default -> 0.85F; // mão (primeira/terceira pessoa), armadura, etc
        };
        poseStack.scale(scale, scale, scale);

        VertexConsumer consumer = buffer.getBuffer(RenderType.entityCutoutNoCull(VerityRenderer.TEXTURE));
        SphereRenderUtil.renderSphere(poseStack, consumer, packedLight, 0.42F, 10, 14);

        poseStack.popPose();
    }
}
