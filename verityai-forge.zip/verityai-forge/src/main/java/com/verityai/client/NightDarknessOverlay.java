package com.verityai.client;

import com.verityai.VerityAIMod;
import com.verityai.item.FlashlightItem;
import net.minecraft.client.Minecraft;
import net.minecraft.client.gui.GuiGraphics;
import net.minecraft.world.item.ItemStack;
import net.minecraft.world.level.Level;
import net.minecraftforge.api.distmarker.Dist;
import net.minecraftforge.client.event.RenderGuiEvent;
import net.minecraftforge.eventbus.api.SubscribeEvent;
import net.minecraftforge.fml.common.Mod;

/**
 * Deixa as noites bem mais escuras (estilo horror, parecido com o mod
 * original) desenhando uma camada preta semi-transparente por cima da
 * tela conforme a hora do dia. É desativado enquanto o jogador segura a
 * Lanterna da Verity ligada.
 */
@Mod.EventBusSubscriber(modid = VerityAIMod.MOD_ID, value = Dist.CLIENT)
public class NightDarknessOverlay {

    private static final long NIGHT_START = 13000L;
    private static final long NIGHT_END = 23000L;

    @SubscribeEvent
    public static void onRenderGuiPost(RenderGuiEvent.Post event) {
        Minecraft mc = Minecraft.getInstance();
        if (mc.player == null || mc.level == null) return;
        if (mc.options.hideGui) return;
        if (mc.level.dimension() != Level.OVERWORLD) return;
        if (isFlashlightActive(mc)) return;

        long time = mc.level.getDayTime() % 24000L;
        float darkness = computeDarkness(time);
        if (darkness <= 0f) return;

        int alpha = (int) (darkness * 190);
        int color = (alpha << 24);

        GuiGraphics graphics = event.getGuiGraphics();
        int width = mc.getWindow().getGuiScaledWidth();
        int height = mc.getWindow().getGuiScaledHeight();
        graphics.fill(0, 0, width, height, color);
    }

    private static float computeDarkness(long time) {
        if (time < NIGHT_START || time > NIGHT_END) return 0f;
        float progress = (time - NIGHT_START) / (float) (NIGHT_END - NIGHT_START); // 0 a 1
        return (float) Math.sin(progress * Math.PI); // sobe, fica no pico, desce
    }

    private static boolean isFlashlightActive(Minecraft mc) {
        ItemStack main = mc.player.getMainHandItem();
        ItemStack off = mc.player.getOffhandItem();
        return FlashlightItem.isActive(main) || FlashlightItem.isActive(off);
    }
}
