package com.verityai.item;

import com.verityai.VerityAIMod;
import net.minecraft.world.effect.MobEffectInstance;
import net.minecraft.world.effect.MobEffects;
import net.minecraft.world.entity.player.Player;
import net.minecraft.world.item.ItemStack;
import net.minecraftforge.event.TickEvent;
import net.minecraftforge.eventbus.api.SubscribeEvent;
import net.minecraftforge.fml.common.Mod;

/**
 * Roda no servidor: se o jogador estiver com a lanterna da Verity ligada
 * (mão principal ou secundária), reaplica visão noturna a cada tick
 * (efeito curto, sem ícone/partícula, some rápido se ele soltar/desligar).
 */
@Mod.EventBusSubscriber(modid = VerityAIMod.MOD_ID)
public class FlashlightEffectHandler {

    @SubscribeEvent
    public static void onPlayerTick(TickEvent.PlayerTickEvent event) {
        if (event.phase != TickEvent.Phase.END) return;

        Player player = event.player;
        if (player.level().isClientSide) return;

        ItemStack main = player.getMainHandItem();
        ItemStack off = player.getOffhandItem();

        if (FlashlightItem.isActive(main) || FlashlightItem.isActive(off)) {
            player.addEffect(new MobEffectInstance(MobEffects.NIGHT_VISION, 220, 0, true, false, false));
        }
    }
}
