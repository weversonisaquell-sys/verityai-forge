package com.verityai.client;

import com.verityai.VerityAIMod;
import com.verityai.ai.GroqService;
import com.verityai.client.gui.VerityChatScreen;
import net.minecraft.client.Minecraft;
import net.minecraft.network.chat.Component;
import net.minecraftforge.api.distmarker.Dist;
import net.minecraftforge.client.event.ClientChatEvent;
import net.minecraftforge.event.TickEvent;
import net.minecraftforge.eventbus.api.SubscribeEvent;
import net.minecraftforge.fml.common.Mod;

import java.util.Locale;

/**
 * Escuta a tecla V (Forge bus, roda todo tick no cliente) e abre a tela de
 * chat da Verity quando nenhuma outra tela estiver aberta. Também escuta o
 * chat normal do Minecraft: se a mensagem começar com "Verity", em vez de
 * mandar pro servidor/mundo, ela é interceptada e enviada pra IA.
 */
@Mod.EventBusSubscriber(modid = VerityAIMod.MOD_ID, value = Dist.CLIENT)
public class ClientForgeEvents {

    private static final String TRIGGER_WORD = "verity";

    @SubscribeEvent
    public static void onClientTick(TickEvent.ClientTickEvent event) {
        if (event.phase != TickEvent.Phase.END) return;

        Minecraft mc = Minecraft.getInstance();
        while (KeyBindings.TALK_KEY.consumeClick()) {
            if (mc.player == null) continue;
            if (mc.screen == null) {
                openChatScreenClientSide();
            }
        }
    }

    public static void openChatScreenClientSide() {
        Minecraft mc = Minecraft.getInstance();
        if (mc.screen == null) {
            mc.setScreen(new VerityChatScreen());
        }
    }

    /**
     * Intercepta o chat vanilla. Digitando "Verity <mensagem>" (ou
     * "Verity: <mensagem>") no chat normal, a mensagem NÃO é enviada pro
     * mundo/servidor - ela vai direto pra IA, e a resposta aparece no
     * próprio chat.
     */
    @SubscribeEvent
    public static void onClientChat(ClientChatEvent event) {
        String raw = event.getMessage().trim();
        if (raw.length() < TRIGGER_WORD.length()) return;

        String lower = raw.toLowerCase(Locale.ROOT);
        if (!lower.startsWith(TRIGGER_WORD)) return;

        // garante que "Verity" é uma palavra isolada (evita cancelar algo
        // tipo "Verityland" por acidente)
        if (raw.length() > TRIGGER_WORD.length()
                && Character.isLetterOrDigit(raw.charAt(TRIGGER_WORD.length()))) {
            return;
        }

        event.setCanceled(true);

        String rest = raw.substring(TRIGGER_WORD.length()).trim();
        if (rest.startsWith(":")) rest = rest.substring(1).trim();

        Minecraft mc = Minecraft.getInstance();
        if (rest.isEmpty()) {
            addChatLine(mc, Component.literal("§7Digite: Verity <sua mensagem>"));
            return;
        }

        addChatLine(mc, Component.literal("§b" + (mc.player != null ? mc.player.getName().getString() : "Você") + ": §f" + rest));

        GroqService.INSTANCE.sendMessageAsync(rest,
                response -> mc.execute(() -> {
                    String cleanText = com.verityai.ai.ItemRequestParser.process(response);
                    addChatLine(mc, Component.literal("§d[Verity] §f" + cleanText));
                }),
                error -> mc.execute(() -> {
                    if ("no_key".equals(error)) {
                        addChatLine(mc, Component.translatable("gui.verityai.chat.no_key"));
                    } else {
                        addChatLine(mc, Component.translatable("gui.verityai.chat.error", error));
                    }
                })
        );
    }

    private static void addChatLine(Minecraft mc, Component component) {
        if (mc.gui != null) {
            mc.gui.getChat().addMessage(component);
        }
    }
}
