package com.verityai.ai;

import com.google.gson.JsonObject;
import com.verityai.VerityAIMod;
import com.verityai.config.VerityConfig;
import net.minecraft.client.Minecraft;
import org.lwjgl.openal.AL10;

import javax.sound.sampled.AudioFormat;
import javax.sound.sampled.AudioInputStream;
import javax.sound.sampled.AudioSystem;
import java.io.ByteArrayInputStream;
import java.io.ByteArrayOutputStream;
import java.net.URI;
import java.net.http.HttpClient;
import java.net.http.HttpRequest;
import java.net.http.HttpResponse;
import java.nio.ByteBuffer;
import java.nio.ByteOrder;
import java.nio.charset.StandardCharsets;
import java.time.Duration;
import java.util.ArrayDeque;
import java.util.Deque;
import java.util.concurrent.CompletableFuture;

/**
 * Faz a Verity falar em voz alta (voz feminina) usando a API de
 * texto-pra-voz da Groq (modelo Orpheus).
 *
 * IMPORTANTE: o áudio é tocado usando o MESMO sistema de som que o
 * próprio Minecraft usa por baixo dos panos (OpenAL, via LWJGL) - em vez
 * da API "crua" javax.sound.sampled.Clip, que não funciona em vários
 * ambientes Android/PojavLauncher (o Java não acha nenhum dispositivo de
 * saída de áudio registrado ali). Como os sons normais do jogo tocam
 * certinho nesses aparelhos, usar o mesmo caminho que eles usam é o jeito
 * mais confiável de garantir que a voz toque de verdade.
 */
public class VerityVoiceService {
    public static final VerityVoiceService INSTANCE = new VerityVoiceService();

    private static final String ENDPOINT = "https://api.groq.com/openai/v1/audio/speech";
    private static final String MODEL = "canopylabs/orpheus-v1-english";
    private static final String VOICE = "hannah"; // voz feminina (modelo em inglês - só existe inglês/árabe na Groq)
    private static final int MAX_CHARS = 190; // limite da Orpheus e 200 caracteres

    private final HttpClient client = HttpClient.newBuilder()
            .connectTimeout(Duration.ofSeconds(15))
            .version(HttpClient.Version.HTTP_1_1) // evita "EOF reached" em ambientes tipo PojavLauncher
            .build();

    private volatile boolean voiceEnabled = true;

    // sources de OpenAL tocando no momento (pra limpar depois que terminam) - só no thread principal
    private final Deque<int[]> activeSources = new ArrayDeque<>();

    public void setVoiceEnabled(boolean enabled) {
        this.voiceEnabled = enabled;
    }

    public boolean isVoiceEnabled() {
        return voiceEnabled;
    }

    public void speakAsync(String text) {
        if (!voiceEnabled || text == null || text.isBlank()) return;

        String apiKey = VerityConfig.getApiKey();
        if (apiKey == null || apiKey.isBlank()) return;

        String cleanText = truncate(text.replaceAll("§.", "").trim());
        if (cleanText.isEmpty()) return;

        JsonObject body = new JsonObject();
        body.addProperty("model", MODEL);
        body.addProperty("input", cleanText);
        body.addProperty("voice", VOICE);
        body.addProperty("response_format", "wav");

        HttpRequest request = HttpRequest.newBuilder()
                .uri(URI.create(ENDPOINT))
                .timeout(Duration.ofSeconds(30))
                .header("Content-Type", "application/json")
                .header("Authorization", "Bearer " + apiKey)
                .POST(HttpRequest.BodyPublishers.ofString(body.toString(), StandardCharsets.UTF_8))
                .build();

        CompletableFuture.supplyAsync(() -> {
            try {
                HttpResponse<byte[]> response = client.send(request, HttpResponse.BodyHandlers.ofByteArray());
                if (response.statusCode() / 100 != 2) {
                    throw new RuntimeException("HTTP " + response.statusCode());
                }
                return response.body();
            } catch (Exception e) {
                throw new RuntimeException(e);
            }
        }).whenComplete((audioBytes, throwable) -> {
            if (throwable != null) {
                VerityAIMod.LOGGER.warn("Falha ao gerar a voz da Verity (TTS)", throwable);
                return;
            }
            // toca no thread principal do jogo - é lá que o contexto do OpenAL do Minecraft está ativo
            Minecraft.getInstance().execute(() -> playViaOpenAL(audioBytes));
        });
    }

    private void playViaOpenAL(byte[] wavBytes) {
        try {
            AudioInputStream in = AudioSystem.getAudioInputStream(new ByteArrayInputStream(wavBytes));
            AudioFormat format = in.getFormat();

            ByteArrayOutputStream rawOut = new ByteArrayOutputStream();
            byte[] chunk = new byte[4096];
            int read;
            while ((read = in.read(chunk)) != -1) {
                rawOut.write(chunk, 0, read);
            }
            byte[] pcm = rawOut.toByteArray();

            int channels = format.getChannels();
            int bitsPerSample = format.getSampleSizeInBits();
            int sampleRate = (int) format.getSampleRate();

            int alFormat;
            if (channels == 1 && bitsPerSample == 16) alFormat = AL10.AL_FORMAT_MONO16;
            else if (channels == 2 && bitsPerSample == 16) alFormat = AL10.AL_FORMAT_STEREO16;
            else if (channels == 1 && bitsPerSample == 8) alFormat = AL10.AL_FORMAT_MONO8;
            else if (channels == 2 && bitsPerSample == 8) alFormat = AL10.AL_FORMAT_STEREO8;
            else {
                VerityAIMod.LOGGER.warn("Formato de audio da voz nao suportado: {} canais, {} bits",
                        channels, bitsPerSample);
                return;
            }

            ByteBuffer pcmBuffer = ByteBuffer.allocateDirect(pcm.length).order(ByteOrder.nativeOrder());
            pcmBuffer.put(pcm);
            pcmBuffer.flip();

            int bufferId = AL10.alGenBuffers();
            AL10.alBufferData(bufferId, alFormat, pcmBuffer, sampleRate);

            int sourceId = AL10.alGenSources();
            AL10.alSourcei(sourceId, AL10.AL_BUFFER, bufferId);
            AL10.alSourcef(sourceId, AL10.AL_GAIN, 1.0F);
            AL10.alSourcei(sourceId, AL10.AL_SOURCE_RELATIVE, AL10.AL_TRUE);
            AL10.alSourcePlay(sourceId);

            activeSources.add(new int[]{sourceId, bufferId});
        } catch (Exception e) {
            VerityAIMod.LOGGER.warn("Nao foi possivel tocar a voz da Verity (OpenAL)", e);
        }
    }

    /** Chamado a cada tick do cliente (ver ClientForgeEvents) pra limpar sources que já terminaram. */
    public void tickCleanup() {
        if (activeSources.isEmpty()) return;
        activeSources.removeIf(pair -> {
            int sourceId = pair[0];
            int state = AL10.alGetSourcei(sourceId, AL10.AL_SOURCE_STATE);
            if (state != AL10.AL_PLAYING) {
                AL10.alDeleteSources(sourceId);
                AL10.alDeleteBuffers(pair[1]);
                return true;
            }
            return false;
        });
    }

    private String truncate(String text) {
        if (text.length() <= MAX_CHARS) return text;
        int cut = text.lastIndexOf(' ', MAX_CHARS);
        if (cut < 0) cut = MAX_CHARS;
        return text.substring(0, cut).trim();
    }
}
