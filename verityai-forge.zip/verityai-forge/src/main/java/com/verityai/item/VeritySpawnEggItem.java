package com.verityai.item;

import com.verityai.client.item.VeritySphereItemRenderer;
import net.minecraft.client.renderer.BlockEntityWithoutLevelRenderer;
import net.minecraft.world.entity.EntityType;
import net.minecraft.world.entity.Mob;
import net.minecraftforge.client.extensions.common.IClientItemExtensions;
import net.minecraftforge.common.ForgeSpawnEggItem;

import java.util.function.Consumer;
import java.util.function.Supplier;

/**
 * Ovo de spawn da Verity: sobrescreve initializeClient para aparecer como
 * uma esfera 3D de verdade (ver VeritySphereItemRenderer), em vez do
 * ícone chato padrão de ovo de spawn.
 *
 * No Forge "puro" (diferente da NeoForge) não existe um evento
 * RegisterClientExtensionsEvent - o item registra sua própria extensão
 * de cliente sobrescrevendo este método.
 */
public class VeritySpawnEggItem extends ForgeSpawnEggItem {

    // Só é usado no lado cliente; instanciado sob demanda (lazy) para não
    // tocar em classes de renderização durante o load do lado servidor.
    private static VeritySphereItemRenderer renderer;

    public VeritySpawnEggItem(Supplier<? extends EntityType<? extends Mob>> type, int backgroundColor, int highlightColor, Properties properties) {
        super(type, backgroundColor, highlightColor, properties);
    }

    @Override
    public void initializeClient(Consumer<IClientItemExtensions> consumer) {
        consumer.accept(new IClientItemExtensions() {
            @Override
            public BlockEntityWithoutLevelRenderer getCustomRenderer() {
                if (renderer == null) {
                    renderer = new VeritySphereItemRenderer();
                }
                return renderer;
            }
        });
    }
}
