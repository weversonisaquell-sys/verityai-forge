package com.verityai.client.item;

import com.verityai.VerityAIMod;
import com.verityai.item.ModItems;
import net.minecraftforge.api.distmarker.Dist;
import net.minecraftforge.client.event.RegisterClientExtensionsEvent;
import net.minecraftforge.client.extensions.common.IClientItemExtensions;
import net.minecraftforge.eventbus.api.SubscribeEvent;
import net.minecraftforge.fml.common.Mod;

@Mod.EventBusSubscriber(modid = VerityAIMod.MOD_ID, bus = Mod.EventBusSubscriber.Bus.MOD, value = Dist.CLIENT)
public class ClientItemRendererSetup {

    @SubscribeEvent
    public static void registerItemExtensions(RegisterClientExtensionsEvent event) {
        VeritySphereItemRenderer sphereRenderer = new VeritySphereItemRenderer();
        IClientItemExtensions extensions = new IClientItemExtensions() {
            @Override
            public net.minecraft.client.renderer.blockentity.BlockEntityWithoutLevelRenderer getCustomRenderer() {
                return sphereRenderer;
            }
        };

        event.registerItem(extensions, ModItems.VERITY_SPAWN_EGG.get());
        event.registerItem(extensions, ModItems.VERITY_BALL.get());
    }
}
