package com.verityai.ai;

import com.google.gson.JsonArray;
import com.google.gson.JsonObject;
import com.google.gson.JsonParser;
import com.verityai.VerityAIMod;
import com.verityai.config.VerityConfig;

import java.net.URI;
import java.net.http.HttpClient;
import java.net.http.HttpRequest;
import java.net.http.HttpResponse;
import java.nio.charset.StandardCharsets;
import java.time.Duration;
import java.util.ArrayDeque;
import java.util.Deque;
import java.util.concurrent.CompletableFuture;
import java.util.function.Consumer;

/**
 * Chama a API do Claude (Anthropic Messages API) num CompletableFuture, sem
 * travar a thread principal do jogo. Guarda um histórico curto da conversa
 * em memória (não persiste entre sessões).
 *
 * Pega sua key em https://console.anthropic.com/settings/keys e configura
 * com /verityai key SUA_KEY dentro do jogo (nunca cole a key direto num
 * chat/print - só no comando, dentro do próprio Minecraft).
 */
public class AnthropicService {

    /** Instância única compartilhada entre a tela (tecla V) e o chat digitado ("Verity ..."). */
    public static final AnthropicService INSTANCE = new AnthropicService();

    private static final String ENDPOINT = "https://api.anthropic.com/v1/messages";
    private static final String ANTHROPIC_VERSION = "2023-06-01";

    private static final String SYSTEM_PROMPT =
            "Você é Verity, uma entidade misteriosa dentro de um mundo de Minecraft, "
            + "inspirada no jogo de terror Verity. Fale em português do Brasil, de forma "
            + "curta (2 a 4 frases), enigmática mas gentil com o jogador. Nunca mencione "
            + "que você é uma IA de verdade ou fale sobre a API do Claude/Anthropic.";

    private final HttpClient client = HttpClient.newBuilder()
            .connectTimeout(Duration.ofSeconds(15))
            .build();

    // histórico simples em memória: pares (role, texto). role = "user" ou "assistant"
    private final Deque<String[]> history = new ArrayDeque<>();
    private static final int MAX_HISTORY_PAIRS = 6;

    public void sendMessageAsync(String userMessage, Consumer<String> onSuccess, Consumer<String> onError) {
        String apiKey = VerityConfig.getApiKey();
        if (apiKey == null || apiKey.isBlank()) {
            onError.accept("no_key");
            return;
        }

        String body = buildRequestBody(userMessage);

        HttpRequest request = HttpRequest.newBuilder()
                .uri(URI.create(ENDPOINT))
                .timeout(Duration.ofSeconds(30))
                .header("Content-Type", "application/json")
                .header("x-api-key", apiKey)
                .header("anthropic-version", ANTHROPIC_VERSION)
                .POST(HttpRequest.BodyPublishers.ofString(body, StandardCharsets.UTF_8))
                .build();

        CompletableFuture.supplyAsync(() -> {
            try {
                HttpResponse<String> response = client.send(request, HttpResponse.BodyHandlers.ofString());
                if (response.statusCode() / 100 != 2) {
                    throw new RuntimeException("HTTP " + response.statusCode() + ": " + trim(response.body()));
                }
                return parseResponseText(response.body());
            } catch (Exception e) {
                throw new RuntimeException(e);
            }
        }).whenComplete((text, throwable) -> {
            if (throwable != null) {
                VerityAIMod.LOGGER.warn("Falha ao chamar a API do Claude", throwable);
                onError.accept(throwable.getCause() != null ? throwable.getCause().getMessage() : throwable.getMessage());
            } else {
                history.addLast(new String[]{"user", userMessage});
                history.addLast(new String[]{"assistant", text});
                while (history.size() > MAX_HISTORY_PAIRS * 2) history.pollFirst();
                onSuccess.accept(text);
            }
        });
    }

    private String buildRequestBody(String userMessage) {
        JsonObject root = new JsonObject();
        root.addProperty("model", VerityConfig.getModel());
        root.addProperty("max_tokens", 256);
        root.addProperty("system", SYSTEM_PROMPT);

        JsonArray messages = new JsonArray();
        for (String[] turn : history) {
            messages.add(turnToMessage(turn[0], turn[1]));
        }
        messages.add(turnToMessage("user", userMessage));
        root.add("messages", messages);

        return root.toString();
    }

    private JsonObject turnToMessage(String role, String text) {
        JsonObject message = new JsonObject();
        message.addProperty("role", role);
        message.addProperty("content", text);
        return message;
    }

    private String parseResponseText(String json) {
        JsonObject root = JsonParser.parseString(json).getAsJsonObject();
        JsonArray content = root.getAsJsonArray("content");
        if (content == null || content.isEmpty()) {
            throw new RuntimeException("Resposta vazia da API");
        }
        StringBuilder sb = new StringBuilder();
        for (var el : content) {
            JsonObject block = el.getAsJsonObject();
            if ("text".equals(block.get("type").getAsString()) && block.has("text")) {
                sb.append(block.get("text").getAsString());
            }
        }
        return sb.toString().trim();
    }

    private String trim(String s) {
        if (s == null) return "";
        return s.length() > 300 ? s.substring(0, 300) + "..." : s;
    }

    public void clearHistory() {
        history.clear();
    }
}
