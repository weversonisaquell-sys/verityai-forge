package com.verityai.entity;

import com.verityai.item.ModItems;
import net.minecraft.sounds.SoundEvents;
import net.minecraft.sounds.SoundSource;
import net.minecraft.world.InteractionHand;
import net.minecraft.world.InteractionResult;
import net.minecraft.world.entity.EntityType;
import net.minecraft.world.entity.PathfinderMob;
import net.minecraft.world.entity.ai.attributes.AttributeSupplier;
import net.minecraft.world.entity.ai.attributes.Attributes;
import net.minecraft.world.entity.ai.goal.RandomLookAroundGoal;
import net.minecraft.world.entity.ai.goal.WaterAvoidingRandomStrollGoal;
import net.minecraft.world.entity.player.Player;
import net.minecraft.world.item.ItemStack;
import net.minecraft.world.level.Level;

/**
 * Entidade base da Verity: uma bolinha que fica NO CHÃO (com gravidade
 * normal) e rola te seguindo por perto, tipo um bichinho de estimação. O
 * visual (uma esfera de verdade, gerada em código) está em
 * client/render/VerityRenderer.java, que também cuida da rotação de
 * "rolar" com base na distância percorrida (ver rollAngle abaixo).
 *
 * Clique na Verity (com a mão vazia ou não) pra capturar ela pro
 * inventário - ela vira o item "Verity" (ovo de spawn). Usar esse ovo
 * num bloco solta ela de novo no mundo (comportamento padrão de ovo de
 * spawn do Minecraft).
 */
public class VerityEntity extends PathfinderMob {

    /** Ângulo acumulado de "rolagem" (radianos), usado só pelo renderer pra girar a esfera visualmente. */
    public float rollAngle;
    private double lastX;
    private double lastZ;
    private boolean rollInitialized = false;

    /** Lado servidor: controla a "fome de conversa" - perde vida se ficar tempo demais sem interação. */
    private static final long NEGLECT_INTERVAL_TICKS = 20L * 60L; // 1 minuto (20 ticks/segundo)
    private static final float HEALTH_LOSS_PER_INTERVAL = 2.0F; // 2 "casinhas" (1 coração inteiro)
    private static final float MIN_HEALTH_FROM_NEGLECT = 2.0F; // nunca morre só de ficar sem conversar
    private long lastTalkGameTime = -1L;

    public VerityEntity(EntityType<? extends PathfinderMob> type, Level level) {
        super(type, level);
        this.setPersistenceRequired(); // não despawna sozinha
    }

    public static AttributeSupplier.Builder createAttributes() {
        return PathfinderMob.createMobAttributes()
                .add(Attributes.MAX_HEALTH, 40.0D)
                .add(Attributes.MOVEMENT_SPEED, 0.28D)
                .add(Attributes.FOLLOW_RANGE, 24.0D);
    }

    @Override
    protected void registerGoals() {
        this.goalSelector.addGoal(1, new FloatFollowPlayerGoal(this, 16.0, 3.0));
        this.goalSelector.addGoal(2, new WaterAvoidingRandomStrollGoal(this, 0.8D));
        this.goalSelector.addGoal(3, new RandomLookAroundGoal(this));
    }

    @Override
    public void tick() {
        super.tick();

        if (this.level().isClientSide) {
            if (!rollInitialized) {
                lastX = this.getX();
                lastZ = this.getZ();
                rollInitialized = true;
                return;
            }

            double dx = this.getX() - lastX;
            double dz = this.getZ() - lastZ;
            double dist = Math.sqrt(dx * dx + dz * dz);
            if (dist > 0.0005) {
                // "rola" proporcional à distância percorrida (radianos = distância / raio)
                rollAngle += (float) (dist / 0.3);
            }
            lastX = this.getX();
            lastZ = this.getZ();
            return;
        }

        // lado servidor: "fome de conversa" - se passar 1 minuto sem falar com ela
        // (chat, voz ou painel), ela perde 2 "casinhas" de vida (nunca morre só por isso)
        if (lastTalkGameTime < 0L) {
            lastTalkGameTime = this.level().getGameTime();
            return;
        }
        long elapsed = this.level().getGameTime() - lastTalkGameTime;
        if (elapsed >= NEGLECT_INTERVAL_TICKS) {
            float newHealth = Math.max(MIN_HEALTH_FROM_NEGLECT, this.getHealth() - HEALTH_LOSS_PER_INTERVAL);
            this.setHealth(newHealth);
            lastTalkGameTime = this.level().getGameTime();
        }
    }

    /** Chamado (via TalkPingPacket) toda vez que o jogador conversa de verdade com ela. */
    public void resetTalkTimer() {
        this.lastTalkGameTime = this.level().getGameTime();
    }

    @Override
    public InteractionResult mobInteract(Player player, InteractionHand hand) {
        if (!this.level().isClientSide) {
            ItemStack egg = new ItemStack(ModItems.VERITY_SPAWN_EGG.get());
            if (!player.getInventory().add(egg)) {
                player.drop(egg, false);
            }
            this.level().playSound(null, this.blockPosition(), SoundEvents.SLIME_SQUISH,
                    SoundSource.NEUTRAL, 1.0F, 1.3F);
            this.discard();
        }
        return InteractionResult.sidedSuccess(this.level().isClientSide);
    }
}
