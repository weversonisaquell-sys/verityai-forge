package com.verityai.client;

import com.verityai.VerityAIMod;
import com.verityai.ai.GroqService;
import com.verityai.ai.ItemRequestParser;
import com.verityai.ai.VerityVoiceService;
import com.verityai.ai.VoiceInputService;
import com.verityai.client.gui.VerityChatScreen;
import com.verityai.network.NetworkHandler;
import com.verityai.network.TalkPingPacket;
import net.minecraft.client.Minecraft;
import net.minecraft.network.chat.Component;
import net.minecraftforge.api.distmarker.Dist;
import net.minecraftforge.client.event.ClientChatEvent;
import net.minecraftforge.event.TickEvent;
import net.minecraftforge.eventbus.api.SubscribeEvent;
import net.minecraftforge.fml.common.Mod;

import java.util.Locale;

/**
 * Cuida da tecla V, do chat digitado ("Verity ...") e centraliza o envio
 * de mensagens pra IA (texto ou voz), incluindo tocar a resposta em voz
 * alta.
 *
 * Tecla V: segura pra falar (grava enquanto está pressionada, manda
 * transcrever quando solta). Se o microfone não estiver disponível nesse
 * aparelho/PojavLauncher, cai automaticamente pro painel de texto (tela de
 * chat), sem travar nada.
 */
@Mod.EventBusSubscriber(modid = VerityAIMod.MOD_ID, value = Dist.CLIENT)
public class ClientForgeEvents {

    private static final String TRIGGER_WORD = "verity";
    private static boolean micActive = false;

    @SubscribeEvent
    public static void onClientTick(TickEvent.ClientTickEvent event) {
        if (event.phase != TickEvent.Phase.END) return;

        Minecraft mc = Minecraft.getInstance();
        if (mc.player == null) return;

        // se qualquer outra tela estiver aberta (inventário, chat de texto, etc),
        // não mexe com a tecla V - evita conflito
        boolean anyScreenOpen = mc.screen != null;
        boolean keyDown = KeyBindings.TALK_KEY.isDown();

        if (keyDown && !micActive && !anyScreenOpen) {
            micActive = true;
            boolean started = VoiceInputService.INSTANCE.startRecording();
            if (started) {
                addChatLine(mc, Component.literal("§7🎤 Gravando... solte V pra enviar"));
            } else {
                // microfone indisponível neste ambiente - cai pro painel de texto
                micActive = false;
                openChatScreenClientSide();
            }
        } else if (!keyDown && micActive) {
            micActive = false;
            handleVoiceResult(mc);
        }
    }

    public static void openChatScreenClientSide() {
        Minecraft mc = Minecraft.getInstance();
        if (mc.screen == null) {
            mc.setScreen(new VerityChatScreen());
        }
    }

    private static void handleVoiceResult(Minecraft mc) {
        VoiceInputService.INSTANCE.stopAndTranscribeAsync(
                text -> mc.execute(() -> {
                    String playerName = mc.player != null ? mc.player.getName().getString() : "Você";
                    addChatLine(mc, Component.literal("§b" + playerName + " (voz): §f" + text));
                    sendToAI(mc, text);
                }),
                error -> mc.execute(() -> {
                    if ("no_key".equals(error)) {
                        addChatLine(mc, Component.translatable("gui.verityai.chat.no_key"));
                    } else {
                        addChatLine(mc, Component.literal(
                                "§7Não consegui entender o áudio. Tenta de novo ou digite \"Verity <mensagem>\"."));
                    }
                })
        );
    }

    /**
     * Intercepta o chat vanilla. Digitando "Verity <mensagem>" (ou
     * "Verity: <mensagem>") no chat normal, a mensagem NÃO é enviada pro
     * mundo/servidor - ela vai direto pra IA, e a resposta aparece no
     * próprio chat (e também é falada em voz alta).
     */
    @SubscribeEvent
    public static void onClientChat(ClientChatEvent event) {
        String raw = event.getMessage().trim();
        if (raw.length() < TRIGGER_WORD.length()) return;

        String lower = raw.toLowerCase(Locale.ROOT);
        if (!lower.startsWith(TRIGGER_WORD)) return;

        // garante que "Verity" é uma palavra isolada (evita cancelar algo
        // tipo "Verityland" por acidente)
        if (raw.length() > TRIGGER_WORD.length()
                && Character.isLetterOrDigit(raw.charAt(TRIGGER_WORD.length()))) {
            return;
        }

        event.setCanceled(true);

        String rest = raw.substring(TRIGGER_WORD.length()).trim();
        if (rest.startsWith(":")) rest = rest.substring(1).trim();

        Minecraft mc = Minecraft.getInstance();
        if (rest.isEmpty()) {
            addChatLine(mc, Component.literal("§7Digite: Verity <sua mensagem>"));
            return;
        }

        addChatLine(mc, Component.literal("§b" + (mc.player != null ? mc.player.getName().getString() : "Você") + ": §f" + rest));
        sendToAI(mc, rest);
    }

    /** Ponto único de envio pra IA - usado pelo chat digitado e pela voz. */
    static void sendToAI(Minecraft mc, String message) {
        GroqService.INSTANCE.sendMessageAsync(message,
                response -> mc.execute(() -> {
                    String cleanText = ItemRequestParser.process(response);
                    addChatLine(mc, Component.literal("§d[Verity] §f" + cleanText));
                    VerityVoiceService.INSTANCE.speakAsync(cleanText);
                    VerityMoodState.onVerityResponded(cleanText);
                    NetworkHandler.CHANNEL.sendToServer(new TalkPingPacket());
                }),
                error -> mc.execute(() -> {
                    if ("no_key".equals(error)) {
                        addChatLine(mc, Component.translatable("gui.verityai.chat.no_key"));
                    } else {
                        addChatLine(mc, Component.translatable("gui.verityai.chat.error", error));
                    }
                })
        );
    }

    static void addChatLine(Minecraft mc, Component component) {
        if (mc.gui != null) {
            mc.gui.getChat().addMessage(component);
        }
    }
}
