package com.verityai.entity;

import com.verityai.client.ModSounds;
import net.minecraft.network.syncher.EntityDataAccessor;
import net.minecraft.network.syncher.EntityDataSerializers;
import net.minecraft.network.syncher.SynchedEntityData;
import net.minecraft.sounds.SoundSource;
import net.minecraft.world.InteractionHand;
import net.minecraft.world.InteractionResult;
import net.minecraft.world.damagesource.DamageSource;
import net.minecraft.world.entity.EntityType;
import net.minecraft.world.entity.EquipmentSlot;
import net.minecraft.world.entity.HumanoidArm;
import net.minecraft.world.entity.LivingEntity;
import net.minecraft.world.entity.ai.attributes.AttributeSupplier;
import net.minecraft.world.entity.ai.attributes.Attributes;
import net.minecraft.world.entity.player.Player;
import net.minecraft.world.item.ItemStack;
import net.minecraft.world.level.Level;
import org.jetbrains.annotations.NotNull;
import software.bernie.geckolib.animatable.GeoEntity;
import software.bernie.geckolib.core.animatable.instance.AnimatableInstanceCache;
import software.bernie.geckolib.core.animation.AnimatableManager;
import software.bernie.geckolib.core.animation.AnimationController;
import software.bernie.geckolib.core.animation.RawAnimation;
import software.bernie.geckolib.core.object.PlayState;
import software.bernie.geckolib.util.GeckoLibUtil;

import java.util.Collections;

/**
 * Caixinha 3D da Verity. Ao interagir (clique direito), toca as falas
 * na ordem box_verity_1 -> box_verity_2 -> box_verity_0 e, quando a
 * caixa efetivamente abre, toca box_click e em seguida box_open,
 * disparando a animação "open" (bones box/flap1/flap2) do GeckoLib.
 */
public class BoxEntity extends LivingEntity implements GeoEntity {

    private final AnimatableInstanceCache cache = GeckoLibUtil.createInstanceCache(this);

    private static final EntityDataAccessor<Boolean> HAS_CLICKED =
            SynchedEntityData.defineId(BoxEntity.class, EntityDataSerializers.BOOLEAN);

    private enum Sequence { NONE, VERITY_1, VERITY_2, VERITY_0, OPEN }

    private Sequence sequence = Sequence.NONE;
    private int sequenceTicks = 0;

    // Duração aproximada de cada som (em ticks, 20 ticks = 1s), com folga.
    private static final int VERITY_1_TICKS = 7;   // ~0.32s
    private static final int VERITY_2_TICKS = 14;  // ~0.66s
    private static final int VERITY_0_TICKS = 11;  // ~0.52s
    private static final int CLICK_TO_OPEN_TICKS = 3; // ~0.15s entre o clique e o som de abrir

    public BoxEntity(EntityType<? extends LivingEntity> entityType, Level level) {
        super(entityType, level);
    }

    @Override
    protected void defineSynchedData() {
        super.defineSynchedData();
        this.entityData.define(HAS_CLICKED, false);
    }

    public static AttributeSupplier.Builder createAttributes() {
        return LivingEntity.createLivingAttributes()
                .add(Attributes.MAX_HEALTH, 20.0)
                .add(Attributes.MOVEMENT_SPEED, 0.0);
    }

    @Override
    public @NotNull InteractionResult interact(Player player, InteractionHand hand) {
        if (!this.level().isClientSide && sequence == Sequence.NONE && !this.entityData.get(HAS_CLICKED)) {
            this.entityData.set(HAS_CLICKED, true);
            startOpenSequence();
            return InteractionResult.CONSUME;
        }
        return super.interact(player, hand);
    }

    private void startOpenSequence() {
        sequence = Sequence.VERITY_1;
        sequenceTicks = 0;
        playEntitySound(ModSounds.BOX_VERITY_1.get());
    }

    @Override
    public void tick() {
        super.tick();
        if (this.level().isClientSide || sequence == Sequence.NONE) return;

        sequenceTicks++;
        switch (sequence) {
            case VERITY_1 -> {
                if (sequenceTicks >= VERITY_1_TICKS) {
                    sequence = Sequence.VERITY_2;
                    sequenceTicks = 0;
                    playEntitySound(ModSounds.BOX_VERITY_2.get());
                }
            }
            case VERITY_2 -> {
                if (sequenceTicks >= VERITY_2_TICKS) {
                    sequence = Sequence.VERITY_0;
                    sequenceTicks = 0;
                    playEntitySound(ModSounds.BOX_VERITY_0.get());
                }
            }
            case VERITY_0 -> {
                if (sequenceTicks >= VERITY_0_TICKS) {
                    sequence = Sequence.OPEN;
                    sequenceTicks = 0;
                    this.triggerAnim("action_controller", "open");
                    playEntitySound(ModSounds.BOX_CLICK.get());
                }
            }
            case OPEN -> {
                if (sequenceTicks == CLICK_TO_OPEN_TICKS) {
                    playEntitySound(ModSounds.BOX_OPEN.get());
                }
                if (sequenceTicks > CLICK_TO_OPEN_TICKS) {
                    sequence = Sequence.NONE;
                }
            }
            default -> {
            }
        }
    }

    private void playEntitySound(net.minecraft.sounds.SoundEvent sound) {
        this.level().playSound(null, this.blockPosition(), sound, SoundSource.NEUTRAL, 1.0f, 1.0f);
    }

    @Override
    public void registerControllers(AnimatableManager.ControllerRegistrar controllers) {
        controllers.add(new AnimationController<>(this, "idle_controller", 5, state -> {
            state.getController().setAnimation(RawAnimation.begin().thenLoop("hover"));
            return PlayState.CONTINUE;
        }));

        AnimationController<BoxEntity> actionController =
                new AnimationController<>(this, "action_controller", 0, state -> PlayState.STOP);
        actionController.triggerableAnim("open", RawAnimation.begin().thenPlayAndHold("open"));
        controllers.add(actionController);
    }

    @Override
    public AnimatableInstanceCache getAnimatableInstanceCache() {
        return this.cache;
    }

    @Override
    public boolean isPushable() {
        return false;
    }

    @Override
    public boolean canBeCollidedWith() {
        return true;
    }

    @Override
    public boolean isPickable() {
        return true;
    }

    @Override
    public boolean hurt(DamageSource source, float amount) {
        return false;
    }

    @Override
    public Iterable<ItemStack> getArmorSlots() {
        return Collections.emptyList();
    }

    @Override
    public ItemStack getItemBySlot(EquipmentSlot slot) {
        return ItemStack.EMPTY;
    }

    @Override
    public void setItemSlot(EquipmentSlot slot, ItemStack stack) {
    }

    @Override
    public HumanoidArm getMainArm() {
        return HumanoidArm.RIGHT;
    }
}
