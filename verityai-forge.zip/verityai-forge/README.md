# Verity AI — Mod Forge para 1.20.1

Mod que adiciona uma entidade "Verity" no mundo (uma bolinha flutuante).
Aperte **V** (ou clique com botão direito nela, ou digite `Verity <msg>`
no chat) pra conversar com ela usando a IA do Claude (Anthropic).

⚠️ **Importante:** eu escrevi todo o código, mas não consegui compilar o
`.jar` aqui porque meu ambiente não tem acesso à internet (o Forge precisa
baixar o MDK e as bibliotecas via Gradle). Você vai precisar compilar num PC
uma vez — depois é só copiar o `.jar` pronto pro celular. Veja o passo a
passo abaixo.

---

## 1. Compilar o mod (sem PC, 100% pelo celular, via GitHub Actions)

O GitHub oferece build na nuvem de graça (GitHub Actions). Este projeto já
vem com o arquivo de configuração pronto (`.github/workflows/build.yml`) -
você só precisa colocar o código lá.

### Passo 1 — Instalar o Termux (terminal Linux pro Android)

Baixe o Termux pela **F-Droid** (não pela Play Store, a versão de lá está
desatualizada e quebrada): https://f-droid.org/packages/com.termux/

### Passo 2 — Instalar git no Termux

Abra o Termux e rode:

```bash
termux-setup-storage
pkg update -y
pkg install -y git unzip
```

(no `termux-setup-storage`, aceite a permissão que o Android pedir — é o
que permite o Termux enxergar sua pasta de Downloads)

### Passo 3 — Criar conta e repositório no GitHub

1. Crie uma conta grátis em **github.com** (pelo navegador do celular)
2. Clique em **"New repository"**, nome `verityai-forge`, deixe
   **Public** ou **Private** (tanto faz), **não** marque "Add a README"
3. Depois de criar, copie a URL que aparece, tipo:
   `https://github.com/SEU_USUARIO/verityai-forge.git`

### Passo 4 — Gerar um token de acesso

O GitHub não aceita mais senha normal pra enviar código, precisa de um
token:

1. No navegador: **Settings > Developer settings > Personal access
   tokens > Tokens (classic) > Generate new token (classic)**
2. Marque a permissão **`repo`**, gere, e **copie o token** (só aparece
   uma vez — guarde num lugar seguro, tipo um app de notas privado)

### Passo 5 — Enviar o código pelo Termux

Baixe o `verityai-forge.zip` que te mandei aqui no chat (vai pra pasta
Downloads do celular). Depois, no Termux:

```bash
cd ~/storage/downloads
unzip verityai-forge.zip
cd verityai-forge
git init
git add .
git commit -m "primeira versao do mod"
git branch -M main
git remote add origin https://github.com/SEU_USUARIO/verityai-forge.git
git push -u origin main
```

Quando pedir usuário e senha: usuário é seu usuário do GitHub, e a
"senha" é o **token** que você gerou no passo 4 (não sua senha normal).

### Passo 6 — Acompanhar o build e baixar o .jar

1. No navegador, vá em `github.com/SEU_USUARIO/verityai-forge/actions`
2. Vai aparecer um build rodando (bolinha amarela) — espera terminar
   (fica verde ✅, leva uns 2-5 minutos)
3. Clica em cima do build concluído, desce até **"Artifacts"**
4. Baixa o arquivo `verityai-jar` (é um `.zip` que contém o `.jar` de
   verdade dentro)
5. Extrai esse zip (o gerenciador de arquivos do Android abre zip
   normalmente) — dentro vai estar o `verityai-1.0.0.jar`

Esse `.jar` é o arquivo final que vai pra pasta `mods` do PojavLauncher.

> Se algum dia você mudar algum código do mod (ex: eu te mandar um
> arquivo atualizado), o processo pra recompilar é só repetir o Passo 5
> (`git add .`, `git commit`, `git push`) — o GitHub recompila sozinho de
> novo.

---

## (Alternativa) Compilar com PC

Se em algum momento você tiver acesso a um PC, também dá pra compilar
direto por lá:

Pré-requisitos:
- **Java 17** instalado ([Adoptium/Temurin 17](https://adoptium.net/temurin/releases/?version=17))
- Este projeto (a pasta `verityai-forge`)

Passos:

```bash
cd verityai-forge

# Linux/Mac:
./gradlew build

# Windows (PowerShell/CMD):
gradlew.bat build
```

A primeira execução demora (baixa o Forge, mapeamentos, etc — só funciona
com internet). Se der tudo certo, o `.jar` final aparece em:

```
build/libs/verityai-1.0.0.jar
```

> Se aparecer erro de "gradlew: Permission denied" no Linux/Mac, rode antes:
> `chmod +x gradlew`
>
> Se faltar o `gradlew`/`gradlew.bat` (não incluí os binários do wrapper),
> rode `gradle wrapper --gradle-version 8.1` uma vez (com Gradle instalado)
> antes do `./gradlew build`.

## 2. Pegar a API key do Claude

1. Acesse **https://console.anthropic.com/settings/keys**
2. Faça login (ou crie uma conta) na Anthropic
3. Clique em "Create Key"
4. Copie a chave (algo como `sk-ant-api03-...`)

⚠️ Essa API é **paga** (não tem um plano grátis generoso como o Gemini
tinha) — você paga só pelo que usar, mas é bom ficar de olho no consumo em
console.anthropic.com. **Nunca** compartilhe essa chave com ninguém, nem
cole ela em prints/mensagens — configure ela só pelo comando
`/verityai key` dentro do próprio jogo (passo 4).

## 3. Instalar no PojavLauncher (celular)

1. Copie `verityai-1.0.0.jar` (do passo 1) para o celular
2. No PojavLauncher, use um perfil com **Forge 1.20.1** já instalado
3. Coloque o `.jar` do mod na pasta `.minecraft/mods/` (crie a pasta `mods`
   se não existir, dentro da pasta do jogo do PojavLauncher)
4. Abra o jogo com o perfil Forge 1.20.1

## 4. Configurar a API key dentro do jogo

Dentro de um mundo, abra o chat normal do Minecraft e digite:

```
/verityai key SUA_KEY_AQUI
```

Isso salva a chave em `config/verityai-client.toml` (fica só no seu
aparelho). Depois disso você pode conversar de duas formas:

- Apertando **V** (abre uma telinha dedicada de chat), ou dando clique
  direito na Verity
- Digitando `Verity sua mensagem` (ou `Verity: sua mensagem`) direto no
  chat normal do Minecraft — a mensagem não é enviada pro mundo/servidor,
  ela vai direto pra IA e a resposta aparece no próprio chat, tipo:

  ```
  Verity onde eu deveria construir minha base?
  [Verity] Nas sombras de uma caverna, longe da luz que revela...
  ```

## 5. Colocar a Verity no mundo

Ainda não adicionei ovo de spawn/comando de invocar por padrão — use o
comando vanilla do Minecraft (precisa de cheats ativados no mundo):

```
/summon verityai:verity
```

## 6. Sobre o formato redondo

A Verity agora é desenhada como uma **esfera de verdade**, gerada
matematicamente dentro do código (`client/render/VerityRenderer.java`) —
não é mais um cubo do Blockbench. Isso porque o formato padrão de
entidades do Minecraft/Forge só suporta caixas retas; pra ficar realmente
redondo, a forma é montada direto em Java, sem depender do Blockbench.

A textura (`assets/verityai/textures/entity/verity.png`) usa mapeamento
**equiretangular** (tipo um mapa-múndi: largura = "dar a volta" na bola,
altura = de polo a polo). Se quiser trocar a textura por uma sua, mantém
esse formato — pode editar a imagem 64x32 num editor comum (não precisa
do Blockbench pra isso).

Se no futuro você quiser adicionar detalhes 3D extras (tipo um chapéu, um
acessório, olhos "para fora" da bola), aí sim o Blockbench (formato
**Modded Entity**) entra em jogo — é só me mandar o `.java` exportado que
eu integro como uma peça extra por cima da esfera.

## Estrutura do projeto

```
src/main/java/com/verityai/
├── VerityAIMod.java          # classe principal, registra tudo
├── VerityCommands.java       # /verityai key <chave>
├── entity/
│   ├── ModEntities.java      # registro do EntityType
│   └── VerityEntity.java     # comportamento (andar, olhar, interagir)
├── client/
│   ├── KeyBindings.java      # tecla V
│   ├── ClientForgeEvents.java# detecta a tecla V e abre o chat
│   ├── render/
│   │   ├── VerityModel.java  # modelo 3D (placeholder -> trocar depois)
│   │   └── VerityRenderer.java
│   └── gui/
│       └── VerityChatScreen.java # tela de chat
├── ai/
│   └── AnthropicService.java # chamada HTTP assíncrona pra API do Claude
└── config/
    └── VerityConfig.java     # onde a API key fica salva
```

## Limitações conhecidas / próximos passos

- Sem animações (o modelo é estático, só anda e olha pro jogador)
- Sem spawn natural nem ovo de spawn no criativo (só `/summon`)
- Histórico de conversa é só em memória (reseta ao fechar o jogo)
- O modelo visual é um placeholder — troque pelo seu do Blockbench
