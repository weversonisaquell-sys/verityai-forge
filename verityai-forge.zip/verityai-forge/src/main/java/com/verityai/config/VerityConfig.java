package com.verityai.config;

import net.minecraftforge.common.ForgeConfigSpec;

public class VerityConfig {
    public static final ForgeConfigSpec CLIENT_SPEC;
    private static final ForgeConfigSpec.ConfigValue<String> API_KEY;
    private static final ForgeConfigSpec.ConfigValue<String> MODEL;

    static {
        ForgeConfigSpec.Builder builder = new ForgeConfigSpec.Builder();
        builder.push("claude");
        API_KEY = builder
                .comment("Sua API key da Anthropic/Claude (crie em https://console.anthropic.com/settings/keys)",
                         "Voce tambem pode setar com o comando /verityai key <SUA_KEY> dentro do jogo.",
                         "NUNCA compartilhe essa chave com ninguem nem cole ela em conversas/prints.")
                .define("apiKey", "");
        MODEL = builder
                .comment("Modelo do Claude usado para gerar as respostas.")
                .define("model", "claude-haiku-4-5-20251001");
        builder.pop();
        CLIENT_SPEC = builder.build();
    }

    // permite setar em runtime via comando, sem precisar reiniciar o jogo
    private static String runtimeApiKeyOverride = null;

    public static String getApiKey() {
        if (runtimeApiKeyOverride != null && !runtimeApiKeyOverride.isBlank()) {
            return runtimeApiKeyOverride;
        }
        return API_KEY.get();
    }

    public static void setApiKey(String key) {
        runtimeApiKeyOverride = key;
        API_KEY.set(key);
        API_KEY.save();
    }

    public static String getModel() {
        String m = MODEL.get();
        return (m == null || m.isBlank()) ? "claude-haiku-4-5-20251001" : m;
    }
}
