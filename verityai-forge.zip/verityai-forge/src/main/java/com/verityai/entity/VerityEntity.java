package com.verityai.entity;

import com.verityai.item.ModItems;
import net.minecraft.sounds.SoundEvents;
import net.minecraft.sounds.SoundSource;
import net.minecraft.world.InteractionHand;
import net.minecraft.world.InteractionResult;
import net.minecraft.world.entity.EntityType;
import net.minecraft.world.entity.PathfinderMob;
import net.minecraft.world.entity.ai.attributes.AttributeSupplier;
import net.minecraft.world.entity.ai.attributes.Attributes;
import net.minecraft.world.entity.ai.goal.RandomLookAroundGoal;
import net.minecraft.world.entity.ai.goal.WaterAvoidingRandomStrollGoal;
import net.minecraft.world.entity.player.Player;
import net.minecraft.world.item.ItemStack;
import net.minecraft.world.level.Level;

/**
 * Entidade base da Verity: uma bolinha que fica NO CHÃO (com gravidade
 * normal) e rola te seguindo por perto, tipo um bichinho de estimação. O
 * visual (uma esfera de verdade, gerada em código) está em
 * client/render/VerityRenderer.java, que também cuida da rotação de
 * "rolar" com base na distância percorrida (ver rollAngle abaixo).
 *
 * Segure Shift e clique nela pra capturar pro inventário (vira o item
 * "Bola da Verity"); clique normal (sem Shift) abre o chat de texto.
 */
public class VerityEntity extends PathfinderMob {

    /** Ângulo acumulado de "rolagem" (radianos), usado só pelo renderer pra girar a esfera visualmente. */
    public float rollAngle;
    private double lastX;
    private double lastZ;
    private boolean rollInitialized = false;

    public VerityEntity(EntityType<? extends PathfinderMob> type, Level level) {
        super(type, level);
        this.setPersistenceRequired(); // não despawna sozinha
    }

    public static AttributeSupplier.Builder createAttributes() {
        return PathfinderMob.createMobAttributes()
                .add(Attributes.MAX_HEALTH, 40.0D)
                .add(Attributes.MOVEMENT_SPEED, 0.28D)
                .add(Attributes.FOLLOW_RANGE, 24.0D);
    }

    @Override
    protected void registerGoals() {
        this.goalSelector.addGoal(1, new FloatFollowPlayerGoal(this, 16.0, 3.0));
        this.goalSelector.addGoal(2, new WaterAvoidingRandomStrollGoal(this, 0.8D));
        this.goalSelector.addGoal(3, new RandomLookAroundGoal(this));
    }

    @Override
    public void tick() {
        super.tick();
        if (!this.level().isClientSide) return;

        if (!rollInitialized) {
            lastX = this.getX();
            lastZ = this.getZ();
            rollInitialized = true;
            return;
        }

        double dx = this.getX() - lastX;
        double dz = this.getZ() - lastZ;
        double dist = Math.sqrt(dx * dx + dz * dz);
        if (dist > 0.0005) {
            // "rola" proporcional à distância percorrida (radianos = distância / raio)
            rollAngle += (float) (dist / 0.3);
        }
        lastX = this.getX();
        lastZ = this.getZ();
    }

    @Override
    public InteractionResult mobInteract(Player player, InteractionHand hand) {
        if (player.isShiftKeyDown()) {
            if (!this.level().isClientSide) {
                ItemStack ball = new ItemStack(ModItems.VERITY_BALL.get());
                if (!player.getInventory().add(ball)) {
                    player.drop(ball, false);
                }
                this.level().playSound(null, this.blockPosition(), SoundEvents.SLIME_SQUISH,
                        SoundSource.NEUTRAL, 1.0F, 1.3F);
                this.discard();
            }
            return InteractionResult.sidedSuccess(this.level().isClientSide);
        }

        // Interagir (botão direito, sem sneak) abre o chat no cliente, além da tecla V.
        if (this.level().isClientSide) {
            com.verityai.client.ClientForgeEvents.openChatScreenClientSide();
        }
        return InteractionResult.sidedSuccess(this.level().isClientSide);
    }
}
