package com.verityai.client.render;

import com.mojang.blaze3d.vertex.PoseStack;
import com.mojang.blaze3d.vertex.VertexConsumer;
import com.verityai.VerityAIMod;
import com.verityai.client.VerityMoodState;
import com.verityai.entity.VerityEntity;
import net.minecraft.client.renderer.MultiBufferSource;
import net.minecraft.client.renderer.RenderType;
import net.minecraft.client.renderer.entity.EntityRenderer;
import net.minecraft.client.renderer.entity.EntityRendererProvider;
import net.minecraft.resources.ResourceLocation;
import net.minecraft.world.phys.Vec3;
import org.joml.Quaternionf;

/**
 * Desenha a Verity como uma esfera de verdade (ver SphereRenderUtil), sem
 * depender de cubos do Blockbench. Ela fica no chão (sem flutuar) e gira
 * de verdade proporcional à distância percorrida, tipo uma bola rolando.
 *
 * A textura do rosto muda com base na VIDA DELA DE VERDADE (a mesma vida
 * que cai quando você fica sem conversar - ver VerityEntity#tick), pra
 * ficar igual à barrinha de humor do HUD (BoxHudOverlay): abaixo de 60%
 * de vida ela fica com cara neutra, e enquanto está "falando" (ver
 * VerityMoodState) usa a variante "_talking" da expressão atual.
 */
public class VerityRenderer extends EntityRenderer<VerityEntity> {
    public static final ResourceLocation TEXTURE_HAPPY =
            new ResourceLocation(VerityAIMod.MOD_ID, "textures/entity/verity.png");
    private static final ResourceLocation TEXTURE_HAPPY_TALKING =
            new ResourceLocation(VerityAIMod.MOD_ID, "textures/entity/verity_happy_talking.png");
    private static final ResourceLocation TEXTURE_NEUTRAL =
            new ResourceLocation(VerityAIMod.MOD_ID, "textures/entity/verity_neutral.png");
    private static final ResourceLocation TEXTURE_NEUTRAL_TALKING =
            new ResourceLocation(VerityAIMod.MOD_ID, "textures/entity/verity_neutral_talking.png");

    /** Abaixo dessa porcentagem de vida, o rosto (e a barra do HUD) ficam neutros. */
    private static final float NEUTRAL_HEALTH_RATIO = 0.6F;

    private static final int LAT_SEGMENTS = 12;
    private static final int LON_SEGMENTS = 16;
    private static final float RADIUS = 0.3F;

    public VerityRenderer(EntityRendererProvider.Context context) {
        super(context);
        this.shadowRadius = 0.35F;
    }

    @Override
    public ResourceLocation getTextureLocation(VerityEntity entity) {
        float healthRatio = entity.getMaxHealth() > 0 ? entity.getHealth() / entity.getMaxHealth() : 1.0F;
        boolean neutral = healthRatio < NEUTRAL_HEALTH_RATIO;
        boolean talking = VerityMoodState.isTalking();
        if (neutral) {
            return talking ? TEXTURE_NEUTRAL_TALKING : TEXTURE_NEUTRAL;
        }
        return talking ? TEXTURE_HAPPY_TALKING : TEXTURE_HAPPY;
    }

    @Override
    public void render(VerityEntity entity, float entityYaw, float partialTicks, PoseStack poseStack,
                        MultiBufferSource bufferSource, int packedLight) {
        poseStack.pushPose();

        // encostada no chão (sem bob/flutuação) - só a altura do próprio raio
        poseStack.translate(0.0, RADIUS, 0.0);

        // rotação de "rolar": gira em torno de um eixo perpendicular à direção
        // do movimento, proporcional à distância percorrida (ver VerityEntity#tick)
        Vec3 velocity = entity.getDeltaMovement();
        double hx = velocity.x;
        double hz = velocity.z;
        double len = Math.sqrt(hx * hx + hz * hz);
        if (len > 0.0005) {
            hx /= len;
            hz /= len;
        } else {
            hx = 0.0;
            hz = 1.0;
        }
        Quaternionf rollRotation = new Quaternionf().rotationAxis(entity.rollAngle, (float) -hz, 0.0F, (float) hx);
        poseStack.mulPose(rollRotation);

        VertexConsumer consumer = bufferSource.getBuffer(RenderType.entityCutoutNoCull(getTextureLocation(entity)));
        SphereRenderUtil.renderSphere(poseStack, consumer, packedLight, RADIUS, LAT_SEGMENTS, LON_SEGMENTS);

        poseStack.popPose();
        super.render(entity, entityYaw, partialTicks, poseStack, bufferSource, packedLight);
    }
}
